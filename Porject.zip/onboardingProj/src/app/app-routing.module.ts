import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PlayVideoComponent } from './video-upload/play-video.component';
import { VideoUploadComponent } from './video-upload/video-upload.component';
import { BlobListComponent } from './video-upload/blob-list.component';

const routes: Routes = [
  { path: 'upload', component: VideoUploadComponent },
  { path: 'play', component: PlayVideoComponent },
  { path: 'delete', component: BlobListComponent },
  { path: '', redirectTo: '/upload', pathMatch: 'full' } // Default route
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

