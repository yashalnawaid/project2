import { Component } from '@angular/core';
import { HttpClient, HttpEventType, HttpEvent } from '@angular/common/http';
import { Subscription } from 'rxjs';
import { IndexedDbService } from './indexed-db.service'; 
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FileDetails } from './file-details.model';
import { Observable, forkJoin, defer,of, tap, switchMap ,  BehaviorSubject, filter, Subject } from 'rxjs';
import {  concatMap, catchError, takeUntil } from 'rxjs/operators';
import { UploadService } from './upload.service';

@Component({
  selector: 'app-video-upload',
  templateUrl: './video-upload.component.html',
  styleUrls: ['./video-upload.component.css']
})
export class VideoUploadComponent {
  uploadProgress:number = 0;
  isUploading: boolean = false;
 

  fileDetailsForm!: FormGroup;
  nextChunkIndex = 0;
  isOnline = navigator.onLine; 
  currentFile!: File;
  chunks: { start: number; end: number; blockId: string }[] = [];
  private resumeIndex = 0;
  totalChunks=0;
  private unsubscribe$ = new Subject<void>();
  uploadUrl ='';

  
  
//-----------------------



  private uploadSubscription: Subscription | null = null;
  private lastUploadedChunkIndex: number = 0;

  private blockIdPrefix: number = 0;
  
  private LastUploadedProgress: number = 0;
//-----------------------



 
  private uploadedChunks: string[] = [];
  


  pauseSubject: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  resumeSubject: Subject<void> = new Subject<void>();
  
  isPaused:boolean = false;




  ngOnInit(): void {
    this.fileDetailsForm = this.formBuilder.group({
      url: [''],
      title: [''],
      description: ['']
    });

  }
  constructor(private http: HttpClient, private formBuilder: FormBuilder, private indexedDbService: IndexedDbService, private uploadService:UploadService) {
    // this.resumeUpload = this.resumeUpload.bind(this);
  
  }

  private async getFileData(file:File){
    const chunks = [];

  }

 
  async onFileChange(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    if (file) {
      this.currentFile = file;
      console.log("in file change method")
      this.uploadFile(file);
    }
  }

  
  onSubmit(blobName:string): void {
    if (this.fileDetailsForm.valid) {
      const formValue = this.fileDetailsForm.value;
      const sasToken = 'sp=racwdli&st=2024-06-10T05:40:20Z&se=2024-07-31T13:40:20Z&spr=https&sv=2022-11-02&sr=c&sig=ncjueqq38%2B2nmcn3ovqi3xHMICFtxjn%2BSvPEkefTD4Y%3D';
      const fileDetails: FileDetails = {
        url: ` https://onboardingproject.blob.core.windows.net/video-uplaod/${blobName}?${sasToken}`,
        title: blobName,
        description: formValue.description
      };
      console.log(fileDetails.url);
      
      this.indexedDbService.saveFileDetails(fileDetails)
        
      .then(() => {
         
          console.log('File details saved successfully');
         
          this.fileDetailsForm.reset();
        })
        .catch(error => {
        
          console.error('Error saving file details:', error);
        });
    } else {
      console.log("form not submitted")
    }
  }
 

uploadFile(file: File): void {
  this.isUploading = true;
  const blobName = file.name;
  const storageAccountName = 'onboardingproject';
  const containerName = 'video-uplaod';
  const sasToken = 'sp=racwdli&st=2024-06-10T05:40:20Z&se=2024-07-31T13:40:20Z&spr=https&sv=2022-11-02&sr=c&sig=ncjueqq38%2B2nmcn3ovqi3xHMICFtxjn%2BSvPEkefTD4Y%3D';
  this.uploadUrl = `https://${storageAccountName}.blob.core.windows.net/${containerName}/${blobName}?${sasToken}`;
  const chunkSize = 10 * 1024 * 1024; // 10 MB
  
  this.totalChunks = Math.ceil(file.size / chunkSize);
  let blockIdPrefix = 0;
  this.uploadedChunks = [];
  this.currentFile = file;
  this.chunks = [];


  for (let index = 0; index < this.totalChunks; index++) {
    const start = index * chunkSize;
    const end = Math.min(start + chunkSize, file.size);
    const blockId = this.generateBlockId(blockIdPrefix++);
    this.chunks.push({ start, end, blockId });
  }

  this.uploadChunks(this.chunks, this.uploadUrl,0);
}


async uploadChunks(chunks: { start: number; end: number; blockId: string }[], uploadUrl: string , startIndex: number) {
  const chunkPromises = [];
  const maxConcurrentRequests = 4;

  for (let i = startIndex; i < chunks.length; i++) {
    if (this.isPaused) {
      this.lastUploadedChunkIndex = i;
      break;
    }

    const chunkData = chunks[i];
    const blockId = chunkData.blockId;
    const slice = this.currentFile.slice(chunkData.start, chunkData.end);
    const reader = new FileReader();

    const uploadPromise = new Promise<void>((resolve, reject) => {
        reader.onload = () => {
          const chunkArrayBuffer = reader.result as ArrayBuffer;
          this.uploadedChunks.push(blockId);
          this.uploadProgress = Math.round((100 * this.uploadedChunks.length) / chunks.length);
          this.http.put(uploadUrl + `&comp=block&blockid=${blockId}`, chunkArrayBuffer, {
            headers: {
              'x-ms-blob-type': 'BlockBlob',
              'Content-Type': 'application/octet-stream',
              // 'Content-Length': chunkArrayBuffer.byteLength.toString()
            },
          reportProgress: true,
          observe: 'events'
        }).toPromise()
          .then((event: any) => {
            if (event.type === HttpEventType.UploadProgress && event.total !== undefined) {
              this.uploadProgress = Math.round((100 * event.loaded) / event.total);
              console.log(this.uploadProgress);
            } else if (event.type === HttpEventType.Response) {
              console.log("Chunk number " + i + " uploaded");
              resolve();
            }
          })
          .catch(error => {
            console.error('Error uploading chunk:', error);
            reject(error);
          });
      };

      reader.readAsArrayBuffer(slice);
    });

    chunkPromises.push(uploadPromise);

    if (chunkPromises.length === maxConcurrentRequests) {
      await Promise.all(chunkPromises);
      chunkPromises.length = 0;
    }
  }

  if (chunkPromises.length > 0) {
    await Promise.all(chunkPromises);
  }
  if (this.uploadedChunks.length === this.totalChunks) {
    this.commitBlocks(this.uploadedChunks, this.currentFile.name);
  }
}


pauseUpload(): void {
  this.isPaused = true;
}


resumeUpload(): void {
  this.isPaused = false;
  const startIndex = this.lastUploadedChunkIndex || 0;
  this.uploadChunks(this.chunks, this.uploadUrl, startIndex);
}




  
  commitBlocks(blockIds: string[], blobName: string): void {
    const storageAccountName = 'onboardingproject';
    const containerName = 'video-uplaod'; 

    const sasToken ='sp=racwdli&st=2024-06-10T05:40:20Z&se=2024-07-31T13:40:20Z&spr=https&sv=2022-11-02&sr=c&sig=ncjueqq38%2B2nmcn3ovqi3xHMICFtxjn%2BSvPEkefTD4Y%3D';
    const uploadUrl = `https://${storageAccountName}.blob.core.windows.net/${containerName}/${blobName}?${sasToken}`;
  
    
    const blockList = `<BlockList>${blockIds.map(id => `<Latest>${id}</Latest>`).join('')}</BlockList>`;
  
    
    this.http.put(uploadUrl + '&comp=blocklist', blockList, {
        headers: {
       
            'Content-Type': 'video/mp4',
            // 'x-ms-date': new Date().toUTCString(), 
            // 'x-ms-version': '2024-11-02', 
            // 'Content-Length': blockList.length.toString(), 
        },
        reportProgress: true,
        observe: 'events'
    }).subscribe({
        next: (event: HttpEvent<any>) => {
            if (event.type === HttpEventType.Response) {
                this.onSubmit(blobName);
                console.log('File uploaded successfully!');
                this.uploadProgress = 0;
                this.isUploading = false;
                this.chunks =[];
            }
        },
        error: (error: any) => {
            console.error('Error committing blocks:', error);
            this.uploadProgress = 0;
            this.isUploading = false;
        }
    });
  }
  

  private generateBlockId = (index: number): string => {
    // making string in the format "block-00000"
    const paddedIndex = index.toString().padStart(5, '0');
    // Concatenate with a fixed prefix
    const blockId = `block-${paddedIndex}`;
    // for Encoding to Base64 & ensure length is 64 characters 
    return btoa(blockId)
  };
  
  
  
  
  
  
    ngOnDestroy() {
      if (this.uploadSubscription) {
        this.uploadSubscription.unsubscribe();
      }
    }

  }
  
  
  
  

















