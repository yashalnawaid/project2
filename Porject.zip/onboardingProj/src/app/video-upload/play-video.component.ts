import { Component, OnInit } from '@angular/core';
import { IndexedDbService } from './indexed-db.service';
import { FileDetails } from './file-details.model';

@Component({
  selector: 'app-play-video',
  templateUrl: './play-video.component.html',
  styleUrls: ['./play-video.component.css']
})
export class PlayVideoComponent implements OnInit {
  videoData: FileDetails[] = [];

  constructor(private indexedDbService: IndexedDbService) { }

  ngOnInit(): void {
    this.getAllVideoData();
  }

  getAllVideoData(): void {
    console.log('hello');
    this.indexedDbService.getAllFileDetails().then(data => {
      this.videoData = data;
      console.log(data);
      console.log('hello');
    }).catch(error => {
      console.error('Error fetching video data:', error);
    });
  }

  constructVideoUrl(video: FileDetails): string {
    
    const baseUrl = 'https://onboardingproject.blob.core.windows.net/video-uplaod/';
    const Title = video.title;
    // const sasToken = '?sp=racwdli&st=2024-06-06T08:32:30Z&se=2024-06-30T16:32:30Z&spr=https&sv=2022-11-02&sr=c&sig=bvnoHtoayV5V2rsj9W2uVKRQn3WR%2BK5344E75G0wj14%3D';
    const sasToken='?sp=racwdli&st=2024-06-10T05:40:20Z&se=2024-07-31T13:40:20Z&spr=https&sv=2022-11-02&sr=c&sig=ncjueqq38%2B2nmcn3ovqi3xHMICFtxjn%2BSvPEkefTD4Y%3D'
    return `${baseUrl}${Title}${sasToken}`;
  }
  
}
