import { Injectable } from '@angular/core';
import { openDB, DBSchema, IDBPDatabase } from 'idb';

interface FileDetails {
  url: string;
  title: string;
  description: string;
}
@Injectable({
  providedIn: 'root'
})
export class IndexedDbService {
  private dbPromise: Promise<IDBPDatabase<FileDetails>> | null = null;

  constructor() {
    this.initDatabase();
  }

  async initDatabase() {
    this.dbPromise = openDB<FileDetails>('fileDetailsDB', 1, {
      upgrade(db) {
        db.createObjectStore('fileDetails', { keyPath: 'url' });
       
      }
    });
  }
  // async initDatabase() {
  //   this.dbPromise = openDB<FileDetails>('fileDetailsDB', 1, {
  //     upgrade(db) {
  //       const store = db.createObjectStore('fileDetails', { keyPath: 'url' });
  //       store.createIndex('titleIndex', 'title'); // Create an index for the 'title' property
  //     }
  //   });
  // }
  
  async saveFileDetails(fileDetails: FileDetails) {
    if (!this.dbPromise) {
      console.error('Database is not initialized');
      return;
    }
    console.log('in save data function');
    const db = await this.dbPromise;
    const tx = db.transaction('fileDetails', 'readwrite');
    const store = tx.objectStore('fileDetails');
    await store.add(fileDetails);
    console.log("saved in indexed db");
  }

  async getFileDetails(url: string): Promise<FileDetails | undefined> {
    if (!this.dbPromise) {
      console.error('Database is not initialized');
      return;
    }
    console.log('data received')
    const db = await this.dbPromise;
    const tx = db.transaction('fileDetails', 'readonly');
    const store = tx.objectStore('fileDetails');
    return store.get(url);
  }


  async getAllFileDetails(): Promise<FileDetails[]> {
    if (!this.dbPromise) {
      console.error('Database is not initialized');
      return [];
    }
  
    console.log('Fetching all data from IndexedDB');
  
    try {
      const db = await this.dbPromise;
      const tx = db.transaction('fileDetails', 'readonly');
      const store = tx.objectStore('fileDetails');
  
      // Use the getAll() method to retrieve all FileDetails objects
      const allFileDetails: FileDetails[] = await store.getAll();
  
      console.log('Retrieved all file details:', allFileDetails);
  
      return allFileDetails;
    } catch (error) {
      console.error('Error fetching data from IndexedDB:', error);
      return [];
    }
  }


  // async deleteFileDetailsByTitle(title: string): Promise<void> {
  //   if (!this.dbPromise) {
  //     console.error('Database is not initialized');
  //     return;
  //   }
  
  //   try {
  //     const db = await this.dbPromise;
  //     const tx = db.transaction('fileDetails', 'readwrite');
  //     const store = tx.objectStore('fileDetails');
  
  //     const index = store.index('titleIndex'); // Use the correct index name 'titleIndex'
  //     const cursor = await index.openCursor(IDBKeyRange.only(title));
  
  //     if (cursor) {
  //       await cursor.delete();
  //       console.log('Record deleted successfully');
  //     } else {
  //       console.log('No record found with title:', title);
  //     }
  //   } catch (error) {
  //     console.error('Error deleting record:', error);
  //   }
  // }
  
  async deleteFileDetailsByTitle(title: string): Promise<void> {
    if (!this.dbPromise) {
      console.error('Database is not initialized');
      return;
    }
  
    try {
      const db = await this.dbPromise;
      const tx = db.transaction('fileDetails', 'readwrite');
      const store = tx.objectStore('fileDetails');
  
     
      const records = await store.getAll();
      const recordToDelete = records.find(record => record.title === title);
  
      if (recordToDelete) {
        await store.delete(recordToDelete.url);
        console.log('Record deleted successfully');
      } else {
        console.log('No record found with title:', title);
      }
    } catch (error) {
      console.error('Error deleting record:', error);
    }
  }
  
}

