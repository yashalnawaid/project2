// import { Injectable } from '@angular/core';
// import { HttpClient } from '@angular/common/http';

// @Injectable({
//   providedIn: 'root'
// })
// export class BlobDeleteService {
//   private readonly storageAccountName = 'onboardingproject';
//   private readonly containerName = 'video-uplaod';
//   private readonly sasToken = 'sp=racwdli&st=2024-06-10T05:40:20Z&se=2024-07-31T13:40:20Z&spr=https&sv=2022-11-02&sr=c&sig=ncjueqq38%2B2nmcn3ovqi3xHMICFtxjn%2BSvPEkefTD4Y%3D';
  

//   constructor(private http: HttpClient) { }
  
//   deleteBlob(blobName: string): Promise<void> {
//     const url = `https://${this.storageAccountName}.blob.core.windows.net/${this.containerName}/${blobName}?${this.sasToken}`;
  
//     return this.http.delete(url, { responseType: 'text' })
//       .toPromise()
//       .then(() => {
//         console.log(`Blob '${blobName}' deleted successfully.`);
//       })
//       .catch(error => {
//         console.error(`Error deleting blob '${blobName}':`, error);
//         throw error; 
//       });
//   }
// }






// new code starts here 


import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IndexedDbService } from './indexed-db.service'; // Import IndexedDbService

@Injectable({
  providedIn: 'root'
})
export class BlobDeleteService {
  private readonly storageAccountName = 'onboardingproject';
  private readonly containerName = 'video-uplaod';
  private readonly sasToken = 'sp=racwdli&st=2024-06-10T05:40:20Z&se=2024-07-31T13:40:20Z&spr=https&sv=2022-11-02&sr=c&sig=ncjueqq38%2B2nmcn3ovqi3xHMICFtxjn%2BSvPEkefTD4Y%3D';
  

  constructor(
    private http: HttpClient,
    private indexedDbService: IndexedDbService // Inject IndexedDbService
  ) { }
  
  deleteBlob(blobName: string): Promise<void> {
    const url = `https://${this.storageAccountName}.blob.core.windows.net/${this.containerName}/${blobName}?${this.sasToken}`;
  
    return this.http.delete(url, { responseType: 'text' })
      .toPromise()
      .then(() => {
        console.log(`Blob '${blobName}' deleted successfully.`);
       
        this.indexedDbService.deleteFileDetailsByTitle(blobName).then(() => {
          console.log(`IndexedDB record for '${blobName}' deleted successfully.`);
        }).catch(error => {
          console.error(`Error deleting IndexedDB record for '${blobName}':`, error);
          throw error;
        });
      })
      .catch(error => {
        console.error(`Error deleting blob '${blobName}':`, error);
        throw error; 
      });
  }
}
