export interface FileDetails {
    url: string;
    title: string;
    description: string;
  }
  