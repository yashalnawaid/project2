// import { TestBed } from '@angular/core/testing';

// import { IndexedDbService } from './indexed-db.service';

// describe('IndexedDbService', () => {
//   let service: IndexedDbService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(IndexedDbService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });



// import { Component } from '@angular/core';
// import { BlobServiceClient, newPipeline, BlockBlobClient, BlockBlobParallelUploadOptions } from '@azure/storage-blob';
// import { IndexedDBService } from 'path-to-your-indexed-db-service'; // Update the path accordingly

// @Component({
//   selector: 'app-video-upload',
//   templateUrl: './video-upload.component.html',
//   styleUrls: ['./video-upload.component.css']
// })
// export class VideoUploadComponent {
//   // Other properties and methods...

//   constructor(private indexedDBService: IndexedDBService) { }

//   async startUpload(file: File) {
//     const fileSize = file.size;
//     const options: BlockBlobParallelUploadOptions = {
//       // Options...
//     };

//     try {
//       await this.blockBlobClient?.uploadData(file, options);
//       // File upload successful, now save file details to IndexedDB
//       const fileDetails: FileDetails = {
//         url: this.blockBlobClient?.url || '', // Assuming blockBlobClient has a 'url' property
//         title: file.name,
//         description: 'Your file description here' // Add your description here
//       };
//       await this.indexedDBService.saveFileDetails(fileDetails);
//     } catch (error) {
//       console.error('Upload error:', error);
//     } finally {
//       this.isUploading = false;
//     }
//   }

//   // Other methods...
// }





// import { Component } from '@angular/core';
// import { BlobServiceClient, newPipeline, BlockBlobClient, BlockBlobParallelUploadOptions } from '@azure/storage-blob';
// import { IndexedDBService } from './indexed-db.service'; // Update the path accordingly
// import { FileDetails } from './file-details.model'; // Update the path accordingly

// @Component({
//   selector: 'app-video-upload',
//   templateUrl: './video-upload.component.html',
//   styleUrls: ['./video-upload.component.css']
// })
// export class VideoUploadComponent {
//   uploadProgress = 0;
//   isUploading = false;
//   blockBlobClient: BlockBlobClient | null = null;
//   resumeToken: any = null;
//   abortController: AbortController | null = null;

//   constructor(private indexedDBService: IndexedDBService) { }

//   async onFileSelected(event: Event) {
//     const file = (event.target as HTMLInputElement)?.files?.[0];
//     if (file) {
//       await this.uploadFile(file);
//     }
//   }

//   async uploadFile(file: File) {
//     this.isUploading = true;

//     const blobServiceClient = new BlobServiceClient(
//       `https://onboardingproject.blob.core.windows.net/video-uplaod?sp=racwdli&st=2024-06-05T05:29:31Z&se=2024-06-05T13:29:31Z&spr=https&sv=2022-11-02&sr=c&sig=QGHk%2FO0F0XNiNtbSgA9M5zMzdCZuuwJVfj%2BUye%2BNWhE%3D`,
//       newPipeline()
//     );
    
//     const containerName = 'video-upload';
//     const containerClient = blobServiceClient.getContainerClient(containerName);

//     const blobName = file.name;
//     this.blockBlobClient = containerClient.getBlockBlobClient(blobName);

//     this.abortController = new AbortController();

//     if (this.resumeToken) {
//       await this.resumeUpload();
//     } else {
//       await this.startUpload(file);
//     }
//   }

//   async UploadFile(file: File) {
//     const fileSize = file.size;
//     const options: BlockBlobParallelUploadOptions = {
//       blockSize: 4 * 1024 * 1024,
//       concurrency: 20,
      
//       onProgress: (ev) => {
//         console.log(ev)
//         const progress = (ev.loadedBytes / fileSize) * 100;
//         this.uploadProgress = Math.round(progress);
//       },
//       maxSingleShotSize: 4 * 1024 * 1024,
//       abortSignal: this.abortController?.signal // Pass the abort signal
//     };

//     try {
//       await this.blockBlobClient?.uploadData(file, options);
//       // File upload successful, now save file details to IndexedDB
//       const fileDetails: FileDetails = {
//         url: this.blockBlobClient?.url || '', // Assuming blockBlobClient has a 'url' property
//         title: file.name, // You can modify this according to your form inputs
//         description: 'Your description here' // You can modify this according to your form inputs
//       };
//       await this.indexedDBService.saveFileDetails(fileDetails);
//     } catch (error) {
//       console.error('Upload error:', error);
//     } finally {
//       this.isUploading = false;
//     }
//   }

//   // Other methods...
// }
