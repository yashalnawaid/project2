import { TestBed } from '@angular/core/testing';

import { BlobDeleteService } from './blob-delete.service';

describe('BlobDeleteService', () => {
  let service: BlobDeleteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BlobDeleteService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
