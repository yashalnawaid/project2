import { Component, OnInit } from '@angular/core';
import { IndexedDbService } from './indexed-db.service';
import { FileDetails } from './file-details.model';
import { BlobDeleteService } from './blob-delete.service';

@Component({
  selector: 'app-blob-list',
  templateUrl: './blob-list.component.html',
  styleUrls: ['./blob-list.component.css']
})
export class BlobListComponent implements OnInit {
  blobList: FileDetails[] = [];

  constructor(
    private indexedDbService: IndexedDbService,
    private blobDeleteService: BlobDeleteService
  ) { }

  ngOnInit(): void {
    this.getAllBlobData();
  }

  getAllBlobData(): void {
    this.indexedDbService.getAllFileDetails().then(data => {
      this.blobList = data;
    }).catch(error => {
      console.error('Error fetching blob data:', error);
    });
  }

  deleteBlob(blob: FileDetails): void {
    const blobName = blob.title; 
    this.blobDeleteService.deleteBlob(blobName).then(() => {
      
      this.blobList = this.blobList.filter(b => b.title !== blobName);
    }).catch(error => {
      console.error('Error deleting blob:', error);
    });
  }
}
