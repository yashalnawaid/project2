import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { VideoUploadComponent } from './video-upload/video-upload.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule,  } from '@angular/material/input'; // Add this if you are using matInput
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { PlayVideoComponent } from './video-upload/play-video.component';
import { BlobListComponent } from './video-upload/blob-list.component';

@NgModule(
  {
  declarations: [
    AppComponent,
    VideoUploadComponent,
    PlayVideoComponent,
    BlobListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule, 
    MatProgressBarModule,
    
 
  ],
  providers: [
    provideAnimationsAsync(),
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
